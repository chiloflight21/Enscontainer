use UID;
create table UID(FirstName varchar(100),LastName varchar(100),UID varchar(100));
